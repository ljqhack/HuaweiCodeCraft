#ifndef _SOLVE_H_
#define _SOLVE_H_

extern void hello();

#endif

